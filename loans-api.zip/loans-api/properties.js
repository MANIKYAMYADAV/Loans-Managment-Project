module.exports={
    DB_PORT:4300,
    DB_URL: "mongodb://localhost:27017/testingDB"
}